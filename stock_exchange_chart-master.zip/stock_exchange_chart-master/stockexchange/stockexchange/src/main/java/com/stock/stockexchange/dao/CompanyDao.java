package com.stock.stockexchange.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.model.User;

public interface CompanyDao extends JpaRepository<Company,Integer> {

	

	@Query("Select c from Company c where c.companyName Like %:name% ")
	List<Company> findMatchningCompany(@Param("name") String name);

	@Query("Select c From Company c  where c.sectorId= :id ")
	List<Company> findCompanyBySector(@Param("id") int id);

	@Query("Select c From Company c where c.companyCode= :id")
	Company getCompanyById(@Param("id") int id);
}
