package com.stock.stockexchange.service;

import java.sql.SQLException;

import com.stock.stockexchange.model.User;

public interface LoginService {
	public User validateUser(int user, String password) throws Exception;
	public User insertUser(User user) throws Exception;
}
