package com.stock.stockexchange.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.stock.stockexchange.model.User;
import com.stock.stockexchange.service.LoginService;

@Controller
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)

	public ModelAndView home(HttpServletRequest request,Model model)
	{
		 model.addAttribute("login", new User());
		 if(null!=(request.getAttribute("message")))
		 {
		 String message1=(String) request.getAttribute("message");
		 request.setAttribute("message",message1);
		 }
		return new ModelAndView("user-login");
	}
	
	
	@RequestMapping(value = "/userLoginProcess", method = RequestMethod.POST)

	public String login(@RequestParam("userId") String userName, @RequestParam("password") String password,
			@ModelAttribute("login") User login,ModelMap map, HttpServletRequest request) 
	{
		User users = new User();
		Boolean check = false;
		int user = Integer.parseInt(userName);
		
			try
			{
				users= loginService.validateUser(user, password);
			} 
			catch (Exception e)
			{
				System.out.println(e);
			}

			if (users!=null)
			{
				return "user-landing-page";
			}

			else if(users==null)
			{
				map.addAttribute("message","Invalid UserId or Password");
				request.setAttribute("message","Invalid UserId or Password" );
                return "user-login";
			} 
			
		return "user-login";

	}
	

	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public String getUserForm(ModelMap model) {
		System.out.println("add user");
		User user = new User();
		
		model.addAttribute("user", user);
		return "registration";
	}
	
	@RequestMapping(value = "/addUserProcess", method = RequestMethod.POST)
	public String formHandler(@Valid @ModelAttribute("user") User user,BindingResult result,
			 Model model) throws Exception 
	{
		if(result.hasErrors())
		{
			System.out.println("eror");
			model.addAttribute("user",user);
			return "registration";
		}
		
		try
		{
		loginService.insertUser(user);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	    return "redirect:/login";
	}
}
