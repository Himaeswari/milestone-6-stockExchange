package com.stock.stockexchange.dao;

public class ApplicationException extends Exception {
	String exceptionerror;

	public ApplicationException(String error) {
		exceptionerror = error;
	}

	public String toString() {
		return (" There is some problem due to " + exceptionerror);
	}

}
