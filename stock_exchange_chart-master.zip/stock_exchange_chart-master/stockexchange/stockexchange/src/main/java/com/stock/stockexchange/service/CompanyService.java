package com.stock.stockexchange.service;

import java.util.List;
import com.stock.stockexchange.model.Company;

public interface CompanyService{

	public Company insertCompany(Company company) throws Exception;

	public List<Company> getCompanyList() throws Exception;

	public List<Company> findMatchingCompany(String name) throws Exception;

	List<Company> findCompanyBySector(int id) throws Exception;

	public Company getCompanyById(int id) throws Exception;

}
